# G-Core DNS Stats Datasource Plugin

[![Build](https://github.com/G-Core/dns-stats-datasource-plugin/actions/workflows/ci.yml/badge.svg)](https://github.com/G-Core/dns-stats-datasource-plugin/actions/workflows/ci.yml)

A Grafana datasource plugin for visualizing G-Core Labs DNS Zone Statistics.

---

## Overview

The G-Core DNS Stats Datasource Plugin extends Grafana's data source capabilities to include DNS zone statistics from G-Core Labs. This plugin enables you to monitor and visualize DNS query patterns, record types, and zone performance metrics directly within your Grafana dashboards.

### Key Features

- **DNS Zone Statistics**: Visualize comprehensive DNS metrics from G-Core API
- **Flexible Filtering**: Filter by specific zone names or use `all` for aggregated statistics across all zones
- **Record Type Support**: Monitor multiple DNS record types (A, AAAA, NS, CNAME, MX, TXT, SVCB, HTTPS)
- **Time-Based Granularity**: Analyze statistics with customizable time ranges
- **Grafana Variables**: Full support for Grafana templating variables for dynamic dashboards

---

## Getting Started

### Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** >= 22
- **Docker** and **Docker Compose**
- **Grafana** >= 12.0

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/G-Core/dns-stats-datasource-plugin.git
   cd dns-stats-datasource-plugin
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

### Development Setup

1. Build the plugin in watch mode:
   ```bash
   npm run dev
   ```

2. In a separate terminal, start Grafana with the plugin:
   ```bash
   npm run server
   ```

3. Access Grafana at [http://localhost:3000](http://localhost:3000)

---

## Configuration

### Data Source Configuration

Configure the datasource in Grafana using either the UI or a provisioning file.

#### Example Provisioning File

Create a YAML file in your Grafana provisioning directory (e.g., `/etc/grafana/provisioning/datasources/`):

```yaml
apiVersion: 1
datasources:
  - name: dns-stats
    orgId: 1
    editable: true
    access: proxy
    type: gcorelabs-dns-stats-datasource
    isDefault: true
    version: 1
    jsonData:
      apiUrl: api.gcore.com/dns/v2
    secureJsonData:
      apiKey: 'apikey 1234$abcdef'
```

#### Configuration Parameters

| Parameter | Description | Required |
|-----------|-------------|----------|
| `apiUrl` | G-Core DNS API endpoint | Yes |
| `apiKey` | Your G-Core API key (format: `apikey <token>`) | Yes |

> **Security Note**: Always keep your API key secure. Never commit API keys to version control. Use Grafana's secure JSON data storage or environment variables for sensitive credentials.

### Using Zone Filters

- **Specific Zone**: Enter the exact zone name (e.g., `example.com`)
- **All Zones**: Use `all` to view aggregated statistics across all your DNS zones

---

## Testing

The plugin includes comprehensive testing capabilities:

### Run Unit Tests
```bash
npm test
```

### Run E2E Tests
```bash
npm run e2e
```

### Type Checking
```bash
npm run typecheck
```

### Linting
```bash
npm run lint
```

---

## Usage

### Creating a Dashboard

1. Add a new panel to your Grafana dashboard
2. Select **dns-stats** as the data source
3. Configure your query:
   - Select a zone name or use `all` for aggregated data
   - Choose DNS record types to monitor
   - Set your desired time range and granularity
4. Customize visualization settings as needed

### Example Dashboard

![DNS Zone Statistics Dashboard](screenshots/DnsZoneTestGraph.png)

The screenshot above shows an example dashboard displaying DNS zone statistics with multiple record types visualized over time.

### Supported DNS Record Types

- **A**: IPv4 address records
- **AAAA**: IPv6 address records
- **NS**: Name server records
- **CNAME**: Canonical name records
- **MX**: Mail exchange records
- **TXT**: Text records
- **SVCB**: Service binding records
- **HTTPS**: HTTPS-specific service binding records

---

## Multiple Grafana Instances

When running multiple Grafana instances, ensure each instance uses the correct version of the datasource configuration. This is particularly important in high-availability setups or when managing multiple environments (development, staging, production).

---


### Common Issues

**Plugin not appearing in Grafana**
- Verify that the plugin is properly built and located in Grafana's plugin directory
- Check Grafana logs for any plugin loading errors
- Ensure Grafana version >= 12.0

**API connection errors**
- Verify your API key is correct and properly formatted
- Check that the API URL is accessible from your Grafana instance
- Ensure your API key has the necessary permissions for DNS statistics

**No data displayed**
- Confirm that you have DNS zones configured in your G-Core account
- Verify the time range includes periods with DNS activity
- Check that the selected zone name exists or use `all` for testing

---


## Links

- [G-Core Labs](https://gcore.com/)
- [Grafana Documentation](https://grafana.com/docs/)
- [Plugin Repository](https://github.com/G-Core/dns-stats-datasource-plugin)

---

## Support

For issues and questions:
- Open an issue on [GitHub](https://github.com/G-Core/dns-stats-datasource-plugin/issues)
- Contact G-Core Labs support
- Consult the [Grafana community](https://community.grafana.com/)
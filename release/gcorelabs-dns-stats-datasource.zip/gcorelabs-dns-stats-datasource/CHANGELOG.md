# Changelog

## 2.0.0
- Migration to Grafana 12

## 1.0.9

- Updating url for stats
